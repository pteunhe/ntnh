#!/bin/bash
./server run -c config.json