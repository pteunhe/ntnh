import os
status=os.system('./start.sh')
